<?php
//this is an api to register users on the server

// +-----------------------------------+
// + STEP 1: include required files    +
// +-----------------------------------+
require_once('../phpInclude/dbconnection.php');

$success=$msg="0";$data=array();
// +-----------------------------------+
// + STEP 2: get data				   +
// +-----------------------------------+
$fbid=$_REQUEST['fbid'];
$googleid=$_REQUEST['googleid'];
$email=$_REQUEST['email'];
$name=$_REQUEST['name']?$_REQUEST['name']:'';
$password=isset($_REQUEST['password']) && $_REQUEST['password'] ? $_REQUEST['password'] : '';


global $conn;

if(!($email && ($fbid || $googleid))){
	$success="0";
	$msg="Incomplete Parameters";
	$data=array();
}

	else{ 
	$sth=$conn->prepare("select * from users where email=:email");
	
	$sth->bindValue("email",$email);
	try{$sth->execute();}catch(Exception $e){echo $e->getMessage();}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	if(count($result)){
		$success="0";
		$msg="You are a existing user";
	}		
	
	else{	
		
	$code=md5($email . rand(1,9999999));
	$sql="insert into users values(DEFAULT,:fbid,:googleid,:name,:email,:token,NOW(),:password)";
		$sth=$conn->prepare($sql);
		if($fbid)$sth->bindValue("fbid",$fbid);
		else $sth->bindValue("fbid","");
		if($googleid)$sth->bindValue("googleid",$googleid);
		else $sth->bindValue("googleid","");
		$sth->bindValue("name",$name);
		$sth->bindValue("email",$email);
		$sth->bindValue("password",$password);
		$sth->bindValue('token',$code);
		$count=0;
		try{$count=$sth->execute();}
		catch(Exception $e){
		echo $e->getMessage();
		}

		
		if($count){
		$success="1";
		$msg="Users Successfully registered";
		$data=$code;
		}
	
	}	
}
if(!$code){$code="";}

// +-----------------------------------+
// + STEP 4: send json data			   +
// +-----------------------------------+
if($success==1){
echo json_encode(array("success"=>$success,"msg"=>$msg,"access_token"=>$code));
}
else
echo json_encode(array("success"=>$success,"msg"=>$msg));
?>