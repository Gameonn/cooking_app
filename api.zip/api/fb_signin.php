<?php
//this is an api to login users

// +-----------------------------------+
// + STEP 1: include required files    +
// +-----------------------------------+
require_once('../phpInclude/dbconnection.php');

$success=$msg="0";$data=array();
// +-----------------------------------+
// + STEP 2: get data				   +
// +-----------------------------------+

//$email=$_REQUEST['email'];
$fbid=$_REQUEST['fbid'];
$googleid=$_REQUEST['googleid'];

if(!($fbid || $googleid)){
	$success="0";
	$msg="Incomplete Parameters";
	$data=array();
}
else{

// +-----------------------------------+
// + STEP 3: perform operations		   +
// +-----------------------------------+
	if($fbid){
		$sql="select users.id as uid,users.*, recipes.id as rid, recipes.*,recipe_type.id as rtid, recipe_type.title as rt_title, recipe_type.image as rt_image
	 from users left join favorites on favorites.user_id=users.id left join recipes on recipes.id=favorites.recipe_id left join recipe_type on recipe_type.id=recipes.recipe_type_id where users.fbid=:fbid";
	 }
	
	elseif($googleid){
		$sql="select users.id as uid,users.*, recipes.id as rid, recipes.*,recipe_type.id as rtid, recipe_type.title as rt_title, recipe_type.image as rt_image
	 from users left join favorites on favorites.user_id=users.id left join recipes on recipes.id=favorites.recipe_id left join recipe_type on recipe_type.id=recipes.recipe_type_id where users.googleid=:googleid";
	}
	 
	 $sth=$conn->prepare($sql);
	 if($fbid) $sth->bindValue("fbid",$fbid);
	 if($googleid) $sth->bindValue("googleid",$googleid);
	try{$sth->execute();}
	catch(Exception $e){
	echo $e->getMessage();
	}
	$result=$sth->fetchAll(PDO::FETCH_ASSOC);
	
	
	if(count($result)){
	
		$success="1";
		$msg="Login successful";
	
		$code=md5($username.rand(1,9999999));
		if($fbid){
		$sth=$conn->prepare("update users set token=:token where fbid=:fbid");
		}
		elseif($googleid){
		$sth=$conn->prepare("update users set token=:token where googleid=:googleid");
		}
		if($fbid) $sth->bindValue('fbid',$fbid);
		$sth->bindValue('token',$code);
		if($googleid) $sth->bindValue('googleid',$googleid);
		$count=0;
		try{$count=$sth->execute();}
		catch(Exception $e){}
		
		//get profile
			$data=array(
				"user_id"=>$result[0]['uid'],
				"fbid"=>$result[0]['fbid']?$result[0]['fbid']:"",
				"googleid"=>$result[0]['googleid']?$result[0]['googleid']:"",
				"name"=>$result[0]['name'],
				"email"=>$result[0]['email'],
				"access_token"=>$code
				
			);
			
			/*foreach($result as $key=>$value){
				if($value['title']){
				$data['recipe'][$key]=array('recipe_id'=>$value['rid'],
				'title'=>$value['title'],
				'recipe_image'=>$value['image']?BASE_PATH."/timthumb.php?src=uploads/".$value['image']:"",
				"prep_time"=>$value['prep_time']?$value['prep_time']:"",
				"cook_time"=>$value['cook_time']?$value['cook_time']:"",
				'dificulty_level'=>$value['diff_level']?$value['diff_level']:"",
				'serves'=>$value['serves']?$value['serves']:"",
				'spicy'=>$value['spicy']?$value['spicy']:"",
				'video_url'=>$value['video_url']?BASE_PATH."/timthumb.php?src=uploads/".$value['video_url']:"",
				'method'=>$value['method_html']?$value['method_html']:"",
				'recipe_type'=>$value['rt_title']?$value['rt_title']:"",
				'recipe_type_image'=>$value['rt_image']?BASE_PATH."/timthumb.php?src=uploads/".$value['rt_image']:""
				);
				}
			}*/		
		}
	else{
		$success="0";
		$msg="Invalid User";
	}

}
// +-----------------------------------+
// + STEP 4: send json data			   +
// +-----------------------------------+

if($success==1){
echo json_encode(array("success"=>$success,"msg"=>$msg,"data"=>$data));
}
else
echo json_encode(array("success"=>$success,"msg"=>$msg));
?>