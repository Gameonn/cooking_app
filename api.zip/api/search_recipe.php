<?php

require_once('../phpInclude/dbconnection.php');
require_once('../GeneralFunctions.php');

$success=$msg="0";
$data=array();

$ingredient_type_id = $_REQUEST['ingredient_type_id'];
$recipe_type_id = $_REQUEST['recipe_type_id'];
$cook_time=$_REQUEST['ready_time']?$_REQUEST['ready_time']:0;

if(!($ingredient_type_id && $recipe_type_id)) {
$success='0';
$msg='Incomplete Parameters';
} 
else {
 $data= GeneralFunctions::getRecipe($ingredient_type_id,$recipe_type_id,$cook_time);
   if($data){
 $success='1';
$msg='Success';  	
 }
 else{
  $success='1';
$msg='No Records Found';  
$data=[];
 }      
}

  echo json_encode(array("success" => $success, "msg"=>$msg,"data" => $data));
?>